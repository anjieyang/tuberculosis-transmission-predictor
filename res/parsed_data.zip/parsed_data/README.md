### README

There are 16 valid maps that could extract building numbers and relatively geographical coordinates. 

Each .xls file will contain the buildings' information including **geographical coordinates. Color, prefix, suffix, range, and category**. 

All the valid buildings have been marked as **valid** in the category column. 